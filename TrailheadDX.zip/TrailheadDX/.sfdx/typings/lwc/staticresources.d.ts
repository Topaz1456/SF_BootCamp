declare module "@salesforce/resourceUrl/SiteSamples" {
    var SiteSamples: string;
    export default SiteSamples;
}
declare module "@salesforce/resourceUrl/vfimagetest" {
    var vfimagetest: string;
    export default vfimagetest;
}
