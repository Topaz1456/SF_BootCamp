import { LightningElement } from 'lwc';

export default class DebtRecoveryOnHoldFlag extends LightningElement {}